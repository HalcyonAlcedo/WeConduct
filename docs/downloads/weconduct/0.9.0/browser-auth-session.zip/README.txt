浏览器认证会话准备
WeConduct 0.9.0

解压后打开 browser-auth-session.weconduct.json。
