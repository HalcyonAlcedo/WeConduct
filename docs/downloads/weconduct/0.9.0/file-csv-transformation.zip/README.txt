CSV 读取与文本输出
WeConduct 0.9.0

解压后打开 file-csv-transformation.weconduct.json。
