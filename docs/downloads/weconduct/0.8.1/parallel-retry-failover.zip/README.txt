并行、重试与故障切换
WeConduct 0.8.1

解压后打开 parallel-retry-failover.weconduct.json。
