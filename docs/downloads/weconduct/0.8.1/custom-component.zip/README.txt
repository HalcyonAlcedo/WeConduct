自定义组件边界
WeConduct 0.8.1

解压后打开 custom-component.weconduct.json。
