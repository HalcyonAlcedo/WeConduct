网页表格导出 Excel
WeConduct 0.8.1

解压后打开 browser-table-to-excel.weconduct.json。
