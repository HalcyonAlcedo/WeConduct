`.wcrun` 打包工作流
WeConduct 0.8.1

解压后打开 wcrun-package-workflow.weconduct.json。
